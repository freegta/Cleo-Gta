Create By haf
instaler 
copy or put the .csa and .fxt file into 
android/data/com.rockstargames.gtasa/
ans PASTE! 

playing the game 
-climbed into the vehicle
-touch 1 and 8 to open spawner
-touch 7 to up
-touch 9 to down
-touch 8 to select
-touch 1 to close
=================== 


Contact me on: 
Facebook: https://www.facebook.com/hafmoddercleo 
gmail : saiyasuper6@gmail.com 

Enjoy!! ^_^